# Design System Strategy: Spiritual Intelligence & Grandeur

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Enlightened Architect."** 

This system moves beyond the cold, sterile nature of typical data intelligence platforms. Instead, it treats temple project tracking as a sacred undertaking, blending the timeless dignity of Vedic tradition with the precision of modern aerospace-grade analytics. 

To break the "template" look, we utilize **Intentional Asymmetry**. Rather than perfectly centered grids, we use weighted layouts where high-contrast Serif typography creates an editorial anchor, allowing data-heavy Sans-Serif components to float in organized, breathable clusters. Overlapping elements—such as a data card partially obscuring a subtle stone-textured background—create a sense of physical depth and "Spiritual Grandeur."

---

## 2. Colors
Our palette balances the warmth of devotion with the coolness of professional oversight.

*   **Primary (Saffron/Gold):** `primary (#8f4e00)` and `secondary (#735c00)` represent the fire of service and the value of legacy. Use these for high-action CTAs and progress indicators.
*   **Surface (The Cream Foundation):** We avoid pure white. `surface (#fbf9f8)` and `surface-container-lowest (#ffffff)` provide a warm, parchment-like base that feels premium and reverent.
*   **Data Accents (Slate/Charcoal):** `tertiary (#545f72)` and `on-surface-variant (#554336)` provide the "Modern Intelligence" feel, grounding the vibrant spiritual colors with analytical sobriety.

### The "No-Line" Rule
**Strict Prohibition:** 1px solid borders for sectioning are forbidden. Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` data widget should sit on a `surface` page background. The transition in tone is the divider.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, fine materials. 
*   **Level 0:** `surface` (The Page)
*   **Level 1:** `surface-container-low` (Major Sections)
*   **Level 2:** `surface-container` (Individual Cards)
*   **Level 3:** `surface-container-high` (Active/Hover states or nested data points)

### The "Glass & Gradient" Rule
To elevate the platform, use Glassmorphism for floating navigation or filter bars. Apply `surface` at 80% opacity with a `20px` backdrop blur. Use subtle linear gradients transitioning from `primary (#8f4e00)` to `primary_container (#ff9933)` for hero metrics to provide a "glow" that flat colors cannot replicate.

---

## 3. Typography
The typography is a dialogue between the ancient and the future.

*   **Display & Headlines (Noto Serif):** These are our "Voice of Tradition." Use `display-lg` and `headline-md` for page titles and temple names. The serif evokes the authority of a sacred text.
*   **Title, Body, & Labels (Inter):** This is our "Voice of Logic." All data points, project statuses, and navigation must use Inter. It provides the high legibility required for complex intelligence tracking.
*   **Hierarchy Note:** Use `on-primary-fixed-variant` for sub-headers to maintain a sophisticated tonal relationship with the saffron accents.

---

## 4. Elevation & Depth
Depth in this system is achieved through **Tonal Layering**, not structural scaffolding.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. This creates a soft, natural "lift" mimicking fine stationery stacked on a stone desk.
*   **Ambient Shadows:** For "floating" elements like Modals, use a shadow with a 24px blur at 6% opacity. Use the color `on-surface` (#1b1c1c) for the shadow tint to ensure it feels like a natural shadow cast by ambient temple light.
*   **The "Ghost Border" Fallback:** If a distinction is absolutely required for accessibility, use `outline-variant` at **15% opacity**. Never use 100% opaque borders.
*   **Texture Integration:** Subtle architectural patterns (lotus motifs) should be applied to `surface-variant` backgrounds using a "Multiply" or "Overlay" blend mode at 5% opacity.

---

## 5. Components

### Buttons
*   **Primary:** `primary` background with `on-primary` text. Use `xl (1.5rem)` rounding. The button should feel like a polished stone.
*   **Secondary:** `secondary-container` background. No border.
*   **Tertiary:** Ghost style. No background; `primary` text.

### Cards & Lists
*   **Cards:** Forbid divider lines. Separate content using `spacing-5 (1.7rem)` vertical gaps. Use `md (0.75rem)` corner radius for a "soft but authoritative" edge.
*   **Lists:** Use a `surface-container-low` background on hover. Use `spacing-3` for internal padding to ensure the data has "room to breathe."

### Input Fields
*   **Style:** Minimalist. Only a bottom-weighted `outline-variant` (20% opacity). When focused, the line transitions to `primary` at 2px thickness.
*   **Labels:** Use `label-md` in `on-surface-variant` for a sophisticated, understated feel.

### Progress Bars & Data Viz
*   **Spiritual Progress:** Use the `primary` (Saffron) to `secondary` (Gold) gradient for temple construction or fundraising bars.
*   **Intelligence Indicators:** Use `tertiary` (Slate) for technical benchmarks or logistical data.

### Additional Specialty Components
*   **The "Vigraha" Avatar:** Circular images of temple deities or project leads should have a `secondary` (Gold) 2px outer ring with a `4px` gap from the image.
*   **Project Milestones:** Use a vertical "Thread of Devotion"—a 2px `outline-variant` line that connects `primary` colored dots, representing the project timeline.

---

## 6. Do's and Don'ts

### Do
*   **Use Whitespace as a Luxury:** High-end design is defined by what you *don't* fill. Use `spacing-10` and `spacing-16` to separate major content blocks.
*   **Embrace Tonal Contrast:** Use `surface-bright` against `surface-dim` to guide the user's eye without needing bold icons.
*   **Respect the Serif:** Let the Serif headers stand alone. Do not crowd them with icons or buttons.

### Don't
*   **Don't Use Pure Black:** It kills the "Spiritual Grandeur." Always use `on-surface` (#1b1c1c) for text.
*   **Don't Use Default Shadows:** Avoid the "fuzzy grey box" look. If it's not an ambient, tinted shadow, don't use it.
*   **Don't Use Hard Corners:** Avoid `none` or `sm` roundedness unless it's for a technical data table. Use `md` or `lg` to maintain the "Soft/Reverent" feel.